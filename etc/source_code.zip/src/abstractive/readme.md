# Abstractive Summarization Model

## Model List

| Model             | Paper                                    | Code |
| ----------------- | ---------------------------------------- | ---- |
| Pointer-Generator | [Link](https://arxiv.org/abs/1704.04368) | Link |
| Bottom-Up         | [Link](https://arxiv.org/abs/1808.10792) | Link |
| Bertsum           | [Link](https://arxiv.org/pdf/1908.08345) | Link |
