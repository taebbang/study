# Extractive Summarization Model

## Model List

| Model       | Paper                                                                    | Code |
| ----------- | ------------------------------------------------------------------------ | ---- |
| TextRank    | [Link](https://web.eecs.umich.edu/~mihalcea/papers/mihalcea.emnlp04.pdf) | Link |
| SummaRunner | [Link](https://arxiv.org/abs/1611.04230)                                 | Link |
| Bertsum     | [Link](https://arxiv.org/pdf/1908.08345)                                 | Link |
